/**
 * Change the index and namespace to your own
 */

const PINECONE_INDEX_NAME = 'chatgpt-plugin';

const PINECONE_NAME_SPACE = 'legal-docs'; //namespace is optional for your vectors

export { PINECONE_INDEX_NAME, PINECONE_NAME_SPACE };
