self.__FONT_LOADER_MANIFEST={
  "pages": {
    "/_app": [
      "static/media/2aaf0723e720e8b9-s.p.woff2"
    ]
  },
  "app": {},
  "appUsingSizeAdjust": false,
  "pagesUsingSizeAdjust": true
}